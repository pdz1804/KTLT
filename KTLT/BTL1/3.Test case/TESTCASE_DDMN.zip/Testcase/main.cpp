#include<bits/stdc++.h>
#include<C:\\Users\\GAMING\\Desktop\\initial\\knight.h>
using namespace std;

string link1 = "input\\";
string link2 = "output\\";

// string link1 = "", link2 = "";

// string link1 = "C:\\Users\\GAMING\\Desktop\\initial\\";

int getRandom(int from, int to) {
    return from + rand() % (to - from + 1);
}

void createFileInput(string file_input, int index) {
    ofstream file;
    file.open(file_input);
    srand((unsigned int)time(0));
    file << getRandom(1, 999) << " " << getRandom(1, 10) << " " << getRandom(0, 99) << " " << getRandom(0, 99) << " " << getRandom(0, 99) << "\n";
    int num = getRandom(1, 20);
    int matrix[17] = {0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 15, 16, 17, 18, 19, 99};
    for(int i = 0; i < num; i ++) {
        int random = getRandom(0, 16);
        if(matrix[random] == 13) {
            file << 13;
            int temp = getRandom(1, 9);
            for(int j = 0; j < temp; j ++) file << getRandom(1, 4);
        } else file << matrix[random];
        if(i != num - 1) file << " ";
    }
    file << "\n";
    file << link1 + "mush_ghost_" + to_string(index) << ","
        << link1 + "asclepius_pack_" + to_string(index) << ","
        << link1 + "merlin_pack_" + to_string(index);
    file.close();
}

void createMushGhost(string file_mush_ghost) {
    ofstream file;
    file.open(file_mush_ghost);
    srand((unsigned int)time(0));
    int n2 = getRandom(1, 100);
    file << n2 << "\n";
    for(int i = 0; i < n2; i ++) {
        file << getRandom(-999, 999);
        if(i != n2 - 1) file << ",";
    }
    file.close();
}

void createAsclepiusPack(string file_asclepius_pack) {
    ofstream file;
    file.open(file_asclepius_pack);
    srand((unsigned int)time(0));
    int r1 = getRandom(1, 10), c1 = getRandom(1, 10);
    file << r1 << endl << c1 << endl;
    for(int i = 0; i < r1; i ++) {
        for(int j = 0; j < c1; j ++) {
            file << getRandom(1, 30);
            if(j != c1 - 1) file << " ";
        }
        if(i != r1 - 1) file << endl;
    }
    file.close();
}

void createMerlinPack(string file_merlin_pack) {
    ofstream file;
    file.open(file_merlin_pack);
    srand((unsigned int)time(0));
    int n9 = getRandom(1, 10);
    file << n9 << endl;
    char alphabet[2] = {'a', 'A'};
    for(int i = 0; i < n9; i ++) {
        int num = getRandom(1, 20);
        for(int j = 0; j < num; j ++) {
            int cas = getRandom(0, 1), offside = getRandom(0, 25);
            char c = alphabet[cas] + offside;
            file << c;
        }
        if(i != n9 - 1) file << endl;
    }
    file.close();
}

void checkTestCase() {
    int i;
    for(i = 1; i <= 100; i ++) {
        cout << "Testcase " << i << ": \n";
        string file_input = link1 + "tc" + to_string(i) + "_input",
            file_output = link2 + "tc" + to_string(i) + "_output";
        int HP, level, remedy, maidenkiss, phoenixdown, rescue,
            _HP, _level, _remedy, _maidenkiss, _phoenixdown, _rescue;
        adventureToKoopa(file_input, HP, level, remedy, maidenkiss, phoenixdown, rescue);

        ifstream outputFile;
        outputFile.open(file_output);
        outputFile >> _HP >> _level >> _remedy >> _maidenkiss >> _phoenixdown >> _rescue;
        outputFile.close();

        if(HP == _HP && level == _level && remedy == _remedy && maidenkiss == _maidenkiss
            && phoenixdown == _phoenixdown && rescue == _rescue) 
            cout << "You are correct tescase " << i << "!" << endl;
        else {
            cout << "You are wrong!\n";
            cout << "Your answer is: " << "HP=" << HP
                << ", level=" << level
                << ", remedy=" << remedy
                << ", maidenkiss=" << maidenkiss
                << ", phoenixdown=" << phoenixdown
                << ", rescue=" << rescue << endl;
            cout << "Testcase is: " << "HP=" << _HP
                << ", level=" << _level
                << ", remedy=" << _remedy
                << ", maidenkiss=" << _maidenkiss
                << ", phoenixdown=" << _phoenixdown << ", rescue=" << _rescue << endl;
            break;
        }
        cout << endl;
    }
    if(i == 101) cout << "\nYou are very good and pass all test!";
    else cout << "\nYou are a chicken!";
}

// Enter Your Source Code


/**
 * You have to code this into your terminal to create testcase
 * g++ -g -o main main.cpp C:\\Users\\GAMING\\Desktop\\initial\knight.cpp -I . -std=c++11
 * for($num = 1; $num -le 3; $num ++){ ./main "$num"
 * Start-Sleep -Milliseconds 1000 }
 */

int main(int argc, char ** argv) {
    // You can create new testcase by following code
    // int i = stoi(argv[1]);
    // cout << "testcase " << i << ":"<< endl;
    // srand((unsigned int)time(0));
    // string file_input = link1 + "tc" + to_string(i) + "_input",
    //     file_mush_ghost = link1 + "mush_ghost_" + to_string(i),
    //     file_asclepius_pack = link1 + "asclepius_pack_" + to_string(i),
    //     file_merlin_pack = link1 + "merlin_pack_" + to_string(i);
    // createFileInput(file_input, i);
    // createMushGhost(file_mush_ghost);
    // createAsclepiusPack(file_asclepius_pack);
    // createMerlinPack(file_merlin_pack);
    // int HP, level, remedy, maidenkiss, phoenixdown, rescue;
    // adventureToKoopa(file_input, HP, level, remedy, maidenkiss, phoenixdown, rescue);

    // string file_output = link2 + "tc" + to_string(i) + "_output";
    // ofstream outputFile;
    // outputFile.open(file_output);
    // outputFile << HP << " " << level << " " << remedy << " " << maidenkiss << " " << phoenixdown << " " << rescue;
    // outputFile.close();

    checkTestCase();
    return 0;
}